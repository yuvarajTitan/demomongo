const MongoClient = require('mongodb').MongoClient

const conurl = `mongodb+srv://admin:admin123@cluster0.mftxc.mongodb.net/myapp?retryWrites=true&w=majority`


function initDB(
    dbname,
    colname,
    successcallback,
    failurecallback
)
{
    MongoClient.connect(conurl, function(err, dbins){
        if(err){
            console.log(`something went wrong ${err}`)
            failurecallback(err)

        } else {
            const dbobj = dbins.db('dbname');
            const dbcol = dbobj.collection('collname')
            console.log('connected....')
            successcallback(dbcol)
        }
    })
}

module.exports = { initDB }